ALTER TABLE "Product" ADD COLUMN "photoUrls" JSONB;
ALTER TABLE "Product" ADD COLUMN "description" TEXT;