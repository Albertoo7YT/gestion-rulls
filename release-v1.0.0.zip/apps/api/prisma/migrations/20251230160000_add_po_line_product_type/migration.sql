-- AlterTable
ALTER TABLE "PurchaseOrderLine" ADD COLUMN     "productType" "ProductType";
