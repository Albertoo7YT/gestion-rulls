-- AlterTable
ALTER TABLE "Settings" ADD COLUMN     "issuerAddressLine1" TEXT,
ADD COLUMN     "issuerAddressLine2" TEXT,
ADD COLUMN     "issuerCity" TEXT,
ADD COLUMN     "issuerCountry" TEXT,
ADD COLUMN     "issuerEmail" TEXT,
ADD COLUMN     "issuerName" TEXT,
ADD COLUMN     "issuerPhone" TEXT,
ADD COLUMN     "issuerPostalCode" TEXT,
ADD COLUMN     "issuerProvince" TEXT,
ADD COLUMN     "issuerTaxId" TEXT;
