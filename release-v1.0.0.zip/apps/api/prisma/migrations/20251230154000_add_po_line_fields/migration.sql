-- AlterTable
ALTER TABLE "PurchaseOrderLine" ADD COLUMN     "productName" TEXT,
ADD COLUMN     "manufacturerRef" TEXT;
